package main.java.model;

public class Userservice {

	public static User getUser(long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
