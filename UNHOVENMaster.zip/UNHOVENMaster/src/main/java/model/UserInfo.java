package main.java.model;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.annotation.XmlRootElement;

import main.java.connectionprovider.ConnectionProvider;


@Path("/User")
public class UserInfo {
	
	public UserInfo()
	{
		
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<User> users()
	{
	
	ArrayList<User> List = new ArrayList<User>();
	
	List = new ConnectionProvider().getUsers();
	return List;
	}
	
	@POST
	@Path("/id")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public User getUser(@PathParam("user_id") long id){
		result Userservice.getUser(id);
	
	
	}
	
	
	
	
	}


	

