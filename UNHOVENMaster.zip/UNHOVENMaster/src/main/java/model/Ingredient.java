package main.java.model;

public class Ingredient {

}
