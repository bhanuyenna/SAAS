package main.java.connectionprovider;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import main.java.model.User;

public class ConnectionProvider {
	private static Connection getConnection() throws URISyntaxException,
			SQLException {
		URI dbUri = new URI(System.getenv("DATABASE_URL"));

		String username = dbUri.getUserInfo().split(":")[0];
		String password = dbUri.getUserInfo().split(":")[1];
                try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String dbUrl = "jdbc:postgresql://"
				+ dbUri.getHost()
				+ ':'
				+ dbUri.getPort()
				+ dbUri.getPath()
				+ "?sslmode=require&ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
		System.out.println(dbUrl);
		return DriverManager.getConnection(dbUrl, username, password);
	}

	public static void main(String[] args) {
		try {
			Connection connection = getConnection();
			Statement stmt = connection.createStatement();
			stmt.executeUpdate("INSERT INTO USERS(user_id,firstName,lastName,passWord) VALUES(1,'BHANU','YENNA','BHANU123');");
			ResultSet rs = stmt.executeQuery("SELECT * FROM USERS");
			while (rs.next()) {
				System.out.println("user_id: " + rs.getString("user_id"));
				System.out.println("firstName: " + rs.getString("firstName"));
				System.out.println("lastName: " + rs.getString("lastName"));
				System.out.println("passWord: " + rs.getString("passWord"));
			}
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<User> getUsers() {
		// TODO Auto-generated method stub
		return null;
	}
}
